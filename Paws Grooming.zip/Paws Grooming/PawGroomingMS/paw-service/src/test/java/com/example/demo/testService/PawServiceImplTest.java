package com.example.demo.testService;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;


import java.util.List;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.example.demo.model.Paw;
import com.example.demo.repository.PawRepository;
import com.example.demo.service.PawService;


@SpringBootTest
class PawServiceImplTest {

	@Autowired
    private PawService pawService;
	@Autowired
	private PawRepository pawRepository;

	@Test
	void testGetServiceListAdmin() {
		List<Paw> serviceAdminList = pawService.getServiceListAdmin();
		assertEquals(true, serviceAdminList.size() != 0);
	}

	@Test
	void testGetServiceListCustomer() {
		List<Paw> serviceCustomerList = pawService.getServiceListCustomer();
		assertEquals(true, serviceCustomerList.size() != 0);
	}
	
	@Test
	void testGetPawById() {
		Paw paw = pawService.getPawById(1);  
	    assertThat(paw.getId()).isEqualTo(1);
	}
	

	@Test
	void testEditService() {
		Paw paw2 = pawRepository.findByName("Detangling Hair");
		paw2.setCost("340/hr");
		pawRepository.save(paw2);
		Paw updatedService = pawRepository.findByName("Detangling Hair");
	    assertThat(updatedService.getCost()).isEqualTo("340/hr");
	}

	@Test
	void testAddPawService() {
		Paw savedService = pawRepository.save(new Paw(6,"Parasites Check","https://upload.wikimedia.org/wikipedia/en/1/14/ParasitesCheck.jpg","260/hr","Yes",new java.sql.Date(2022-11-29),"Medium Dogs","No"));  
	    assertThat(savedService.getId()).isGreaterThan(0);
	}

	@Test
	@Rollback(false)
	public void testDeletePawService() {
	    Paw paw = pawRepository.findByName("Parasites Check");
	    pawService.deletePawService(paw.getId());
	    Paw deletedService = pawRepository.findByName("Parasites Check"); 
	    assertThat(deletedService).isNull();       
	     
	}
	
}








