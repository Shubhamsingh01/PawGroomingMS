package com.example.demo.testController;
import org.junit.jupiter.api.Test;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.demo.model.Paw;
import com.example.demo.repository.PawRepository;
import com.example.demo.service.PawServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest
@ExtendWith(SpringExtension.class)
class PawControllerTest {
	@Autowired
	MockMvc mockMvc;

	@MockBean
	PawRepository pawRepository;

	@MockBean
	PawServiceImpl pawServiceImpl;

	@Test
	public void testShowServiceListAdmin() throws Exception {
		mockMvc.perform(get("/services/admin")).andExpect(status().isOk());
	}

	@Test
	public void testShowServiceListCustomer() throws Exception {
		mockMvc.perform(get("/services/customer")).andExpect(status().isOk());
	}
	@Test
	public void testAddPawService() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/services")
						.content(asJsonString(new Paw(6,"No","Yes","260/hr","Parasites Check",new java.sql.Date(2022-11-29),"https://upload.wikimedia.org/wikipedia/en/1/14/ParasitesCheck.jpg","Medium dogs")))
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)

		).andExpect(status().isCreated());
	}

	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			final String jsonContent = mapper.writeValueAsString(obj);
			return jsonContent;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	@Test
	void testDeleteServiceById200OkTest() throws Exception {
		mockMvc.perform(delete("/services/2")).andExpect(status().isOk());
	}
	
	@Test
	void testUdateServiceById200OkTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.put("/services/edit")
						.content(asJsonString(new Paw(1,"Yes","Yes","400/hr","Detangling Hair",new java.sql.Date(2020-04-20),"https://upload.wikimedia.org/wikipedia/en/f/f8/Detanglig_hair.jpg","Large dogs")))
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)

		).andExpect(status().isOk());
	}
	
	/*
	 * @Test public void testGetServiceById() throws Exception {
	 * mockMvc.perform(get("/services/1")).andExpect(status().isOk()); }
	 * 
	 * @Test public void testServiceByIdException() throws Exception {
	 * mockMvc.perform(get("/services/5")).andExpect(status().isOk()); }
	 */
}
