package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Paw;


@Repository
public interface PawRepository extends JpaRepository<Paw, Integer>{

	@Query("select p from Paw p where active='Yes' or active='yes' and dateOfLaunch<=sysdate()")
	List<Paw> findAllCustomer();
	
	public Paw findByName(String name);

}
