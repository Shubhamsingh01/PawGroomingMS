package com.example.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Paw;
import com.example.demo.service.PawService;


@RestController
@RequestMapping("/services")
public class PawController {
	private static final Logger LOGGER = LoggerFactory.getLogger(PawController.class);
	@Autowired
	private PawService movieService;

	@GetMapping("/admin")
	public List<Paw> showServiceListAdmin()  {
		LOGGER.info("Start");
		List<Paw> pawList = movieService.getServiceListAdmin();
		LOGGER.debug("Admin Movie List: {}", pawList);
		LOGGER.info("End");
		return pawList;
	}

	@GetMapping("/customer")
	public List<Paw> showServiceListCustomer() {
		LOGGER.info("Start");
		List<Paw> pawList = movieService.getServiceListCustomer();
		LOGGER.debug("Customer Movie List: {}", pawList);
		LOGGER.info("End");
		return pawList;
	}

	@PutMapping("/edit")
	public String showEditService(@RequestBody Paw paw) {
		LOGGER.info("Start");
		String editedMovie=movieService.editService(paw);
		LOGGER.debug("Movie:{}", paw);
		LOGGER.info("End");
		return editedMovie;
	}
	@PostMapping
	@ResponseStatus(code=HttpStatus.CREATED)
	public String addPawService(@RequestBody Paw paw) {
		LOGGER.info("Start");
		LOGGER.info("End");
		return movieService.addPawService(paw);
	}
	@DeleteMapping("/{pawId}")
	public String deleteService(@PathVariable int pawId) {
		LOGGER.info("Start");
		LOGGER.info("End");
		return movieService.deletePawService(pawId);
	}
}
