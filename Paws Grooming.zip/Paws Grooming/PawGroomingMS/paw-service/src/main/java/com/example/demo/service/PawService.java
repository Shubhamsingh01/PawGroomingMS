package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Paw;




public interface PawService {

	public List<Paw> getServiceListAdmin();
	public List<Paw> getServiceListCustomer();
	public String editService(Paw paw);
	public String addPawService(Paw paw);
	public String deletePawService(int pawId);
	public Paw getPawById(int id);

}
