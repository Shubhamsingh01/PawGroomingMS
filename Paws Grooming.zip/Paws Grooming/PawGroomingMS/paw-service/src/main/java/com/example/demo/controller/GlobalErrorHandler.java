package com.example.demo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.demo.exception.PawException;


@RestControllerAdvice
public class GlobalErrorHandler {

	@ExceptionHandler(PawException.class)
	public ResponseEntity<String> handleNotFoundError(PawException ex){
		ResponseEntity<String> re=new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_FOUND);
		return re;
	}
		
}
