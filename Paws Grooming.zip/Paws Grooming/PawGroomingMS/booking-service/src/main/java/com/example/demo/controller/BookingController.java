package com.example.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Booking;
import com.example.demo.service.BookingService;



@RestController
@RequestMapping("/booking")
public class BookingController {
	
	@Autowired
	BookingService bookingService;
	private static final Logger LOGGER = LoggerFactory.getLogger(BookingController.class);


	@PostMapping("/{userId}/{pawId}")
	public String addBookingService(@PathVariable int userId,@PathVariable int pawId) {
		LOGGER.info("Start");
		LOGGER.info("End");
		return bookingService.addBookingService(userId, pawId);
	}
	
	@GetMapping("/{userId}")
	public List<Booking> getAllBookingService(@PathVariable int userId) {
		LOGGER.info("End");
		LOGGER.info("End");
		return bookingService.getAllBookingService(userId);
	}
	@DeleteMapping("/{userId}/{pawId}")
	public String deleteBookingService(@PathVariable int userId,@PathVariable int pawId) {
		LOGGER.info("End");
		LOGGER.info("End");
		return bookingService.deleteBookingService(userId, pawId);
	}
	@GetMapping("/total/{userId}")
	public String totalBookedService(@PathVariable int userId) {
		LOGGER.info("Start");
		LOGGER.info("End");
		return bookingService.totalBookingService(userId);
	}
	
	@GetMapping("/service/{bookingId}")
	public List<Booking> getBookingById(@PathVariable int bookingId) {
		LOGGER.info("End");
		LOGGER.info("End");
		return bookingService.getBookingById(bookingId);
	}
	
	 @PutMapping("/serviceApprove/{bookingId}") 
	  public String showApproveBooking(@PathVariable int bookingId ,@RequestBody Booking booking) 
	  { 
	  LOGGER.info("Start"); 
	  String Booked=bookingService.approveBooking(booking);
	  LOGGER.debug("booking:{}", booking); 
	  LOGGER.info("End"); 
	  return Booked; 
	  }
}
