package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.PawException;
import com.example.demo.model.Paw;
import com.example.demo.repository.PawRepository;

@Service
public class PawServiceImpl implements PawService {

	@Autowired
	PawRepository pawRepository;
	private static final Logger LOGGER = LoggerFactory.getLogger(PawServiceImpl.class);

	@Override
	public List<Paw> getServiceListAdmin() {
		// TODO Auto-generated method stub
		LOGGER.info("Start");
		List<Paw> pawList= pawRepository.findAll();
		LOGGER.info("End");
		return pawList;
	}

	@Override
	public List<Paw> getServiceListCustomer() {
		// TODO Auto-generated method stub
		LOGGER.info("Start");
		List<Paw> pawList= pawRepository.findAllCustomer();
		LOGGER.info("End");
		return pawList;
	}
	
	public Paw getPawById(int id) {
		
		LOGGER.info("Start");
		java.util.Optional<Paw> services=pawRepository.findById(id);
		if(!services.isPresent()) {
			throw new PawException("Paws Service with id "+ id+" does not exist");
		}
		Paw services2=services.get();
		LOGGER.info("End");
		return services2;
	}
	
	@Override
	public String editService(Paw paw) {
		LOGGER.info("Start");
		int id=paw.getId();
		getPawById(id);
		Optional<Paw> m=pawRepository.findById(paw.getId());
		Paw m2=m.get();
		if(paw.getName()!=null) {
			m2.setName(paw.getName());
		}
	
		if(paw.getHasDiscount()!=null) {
			m2.setHasDiscount(paw.getHasDiscount());
		}
		if(paw.getTarget()!=null) {
			m2.setTarget(paw.getTarget());
		}
		if(paw.getCost()!=null) {
			m2.setCost(paw.getCost());
		}
		if(paw.getDateOfLaunch()!=null) {
			m2.setDateOfLaunch(paw.getDateOfLaunch());
		}
		if(paw.getActive()!=null) {
			m2.setActive(paw.getActive());
		}
		pawRepository.save(m2);
		LOGGER.info("End");
		return "Service with id "+paw.getId()+" Updated Successfully";
	}
	
	@Override
	public String addPawService(Paw paw) {
		LOGGER.info("Start");
		Optional<Paw> op=pawRepository.findById(paw.getId());
		if(op.isPresent()) {
			throw new PawException("Movie with the Id "+paw.getId()+" already exist");
		}
		pawRepository.save(paw);
		LOGGER.info("End");
		return "Service with id "+paw.getId()+" Added Successfully";
	}

	@Override
	public String deletePawService(int pawId) {
		LOGGER.info("Start");
		Optional<Paw> op=pawRepository.findById(pawId);
		if(!op.isPresent()) {
			throw new PawException("Movie with the Id "+pawId+" does not not exist");
		}
		pawRepository.deleteById(pawId);
		LOGGER.info("End");
		return "Service with id "+pawId+" Deleted Successfully";
	}

	

}
