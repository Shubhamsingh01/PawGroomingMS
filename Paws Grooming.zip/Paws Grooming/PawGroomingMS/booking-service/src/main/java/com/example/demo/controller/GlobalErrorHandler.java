package com.example.demo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.demo.exception.BookingException;
import com.example.demo.exception.PawException;
import com.example.demo.exception.UserException;



@RestControllerAdvice
public class GlobalErrorHandler {

	@ExceptionHandler(PawException.class)
	public ResponseEntity<String> handleNotFoundError(PawException ex){
		ResponseEntity<String> re=new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_FOUND);
		return re;
	}
	
	@ExceptionHandler(BookingException.class)
	public ResponseEntity<String> handleNotFoundError(BookingException ex){
		ResponseEntity<String> re=new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_FOUND);
		return re;
	}
	@ExceptionHandler(UserException.class)
	public ResponseEntity<String> handleNotFoundError(UserException ex){
		ResponseEntity<String> re=new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_FOUND);
		return re;
	}
	
}
