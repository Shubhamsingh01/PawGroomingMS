package com.example.demo.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Booking;



@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer>{
	
	@Query("select b from Booking b where b.user.id=?1")
	public List<Booking> findById(int id);

	@Transactional
	@Modifying
	@Query("Delete from Booking b where b.user.id=?1 and b.paw.id=?2")
	public void deleteById(int userId, int pawId);

	@Query("select b from Booking b where b.user.id=?1 and b.paw.id=?2")
	public Booking findById(int userId, int pawId);

	@Query("select b from Booking b where b.id=?1")
	public List<Booking> findByBookingId(int id);
	
	@Query("select b from Booking b where b.id=?1")
	public Booking findId(int id);
}
