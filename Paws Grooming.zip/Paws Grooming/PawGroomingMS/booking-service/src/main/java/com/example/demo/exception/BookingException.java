package com.example.demo.exception;

public class BookingException extends RuntimeException{

	public BookingException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
