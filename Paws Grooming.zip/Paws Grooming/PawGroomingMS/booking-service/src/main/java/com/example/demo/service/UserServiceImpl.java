package com.example.demo.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.UserException;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;





@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);
	
	@Override
	public void saveUser(User user) {
		LOGGER.info("Start");
		userRepository.save(user);
		LOGGER.info("End");
	}

	@Override
	public User getById(int userId) {
		LOGGER.info("Start");
		LOGGER.info("End");
		//return userRepository.findById(id).orElseThrow(()-> new UserNotFoundException("User Not Found")) ;
		Optional<User> user=userRepository.findById(userId);
		if(!user.isPresent()) {
			throw new UserException("User Not Found");
		}
		User user1=user.get();
		
		return user1;
	}

}
