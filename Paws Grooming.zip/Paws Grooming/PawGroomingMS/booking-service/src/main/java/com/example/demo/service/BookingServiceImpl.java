package com.example.demo.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.controller.BookingController;
import com.example.demo.exception.BookingException;
import com.example.demo.exception.PawException;
import com.example.demo.model.Booking;
import com.example.demo.model.Paw;
import com.example.demo.model.User;
import com.example.demo.repository.BookingRepository;




@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	BookingRepository bookingRepository;
	@Autowired
	private UserServiceImpl userService;
	@Autowired
	private PawServiceImpl pawService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BookingController.class);

	@Override
	public String addBookingService(int userId, int pawId) {
		// TODO Auto-generated method stub
		LOGGER.info("Start");
		User u=userService.getById(userId);
		Paw p=pawService.getPawById(pawId);
		Booking f1=bookingRepository.findById(userId,pawId);
		if(f1!=null) {
			throw new PawException("Service with id "+pawId+" already exist");
		}
		Booking bookings=new Booking();
		bookings.setPaw(p);
		bookings.setUser(u);
		bookingRepository.save(bookings);
		LOGGER.info("End");
		return "Service Booked Successfully waiting for approval";
	}

	@Override
	public List<Booking> getAllBookingService(int userId) {
		// TODO Auto-generated method stub
		LOGGER.info("Start");
		userService.getById(userId);
		List<Booking> bookings=bookingRepository.findById(userId);
		if(bookings.isEmpty()) {
			throw new BookingException("Your Booking List is Empty");
		}
		LOGGER.info("End");
		return bookings;
	}

	@Override
	public String deleteBookingService(int userId, int pawId) {
		// TODO Auto-generated method stub
		LOGGER.info("Start");
		userService.getById(userId);
		List<Booking> b=bookingRepository.findById(userId);
		if(b.isEmpty()) {
			throw new BookingException("Booking List is empty");
		}
		Booking b1=bookingRepository.findById(userId,pawId);
		if(b1==null) {
			throw new BookingException("Service does not exist");
		}
		bookingRepository.deleteById(userId, pawId);
		LOGGER.info("End");
		return "Service cancelled successfully";
	}

	@Override
	public String totalBookingService(int userId) {
		// TODO Auto-generated method stub
		LOGGER.info("Start");
		List<Booking> bookings=getAllBookingService(userId);
		int total=bookings.size();
		LOGGER.info("End");
		return "Total Number of Booked Services of userId "+userId+" is "+total;
	}
	
	
	@Override
	public List<Booking> getBookingById(int bookingId) {
		// TODO Auto-generated method stub
		LOGGER.info("Start");
		userService.getById(bookingId);
		List<Booking> booking=bookingRepository.findByBookingId(bookingId);
		if(booking.isEmpty()) {
			throw new BookingException("No Booking with this Id");
		}
		LOGGER.info("End");
		return booking;
	}
	
	@Override
	public String approveBooking(Booking booking) {
		LOGGER.info("Start");
		Booking book=bookingRepository.getOne(booking.getId());
		book.setStatus("Approved");
		book.setGroomer(booking.getGroomer());
		book.setContact(booking.getContact());
		book.setDate(booking.getDate());
		book.setTime(booking.getTime());
		bookingRepository.save(book);
		LOGGER.info("End");
		return "Booking with id "+booking.getId()+" Booked Successfully";
	} 
}
