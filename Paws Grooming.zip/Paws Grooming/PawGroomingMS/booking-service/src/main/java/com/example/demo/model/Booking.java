package com.example.demo.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "booking")
public class Booking {
	
	@Id
	@Column(name = "book_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@ManyToOne
	@JoinColumn(name = "book_us_id")
	private User user;
	@ManyToOne
	@JoinColumn(name = "book_sr_id")
	private Paw paw;
	
	@Column(name = "bookingDate",columnDefinition = "date default '0001-01-01'")
	private Date date;
	
	@Column(name = "BookingTime" ,columnDefinition = "varchar(255) default '00:00'")
	private String time;

	@Column(name ="status",columnDefinition = "varchar(255) default 'Pending'")
    private String status;
	
	@Column(name="groomer",columnDefinition = "varchar(255) default 'N/A'" )
	private String groomer;
	
	@Pattern(regexp="(^$|[0-9]{10})")
	@Column(name="contact",columnDefinition = "varchar(255) default 'xxxxxxxxx'" )
    private String contact;
}
