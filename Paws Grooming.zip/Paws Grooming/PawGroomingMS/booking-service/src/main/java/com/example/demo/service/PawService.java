package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Paw;




public interface PawService {

	public List<Paw> getServiceListAdmin();
	public List<Paw> getServiceListCustomer();
	public String editService(Paw movie);
	public String addPawService(Paw movie);
	public String deletePawService(int movieId);

}
