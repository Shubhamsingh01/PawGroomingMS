package com.example.demo.exception;

public class PawException extends RuntimeException{

	public PawException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PawException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
