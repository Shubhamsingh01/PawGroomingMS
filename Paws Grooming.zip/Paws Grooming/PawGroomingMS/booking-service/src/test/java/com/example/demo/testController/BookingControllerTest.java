package com.example.demo.testController;


import org.junit.jupiter.api.Test;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.demo.model.Booking;
import com.example.demo.model.Paw;
import com.example.demo.model.User;
import com.example.demo.repository.BookingRepository;
import com.example.demo.service.BookingServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest
@ExtendWith(SpringExtension.class)
class BookingControllerTest {
	@Autowired
	MockMvc mockMvc;

	@MockBean
	BookingRepository bookingRepository;

	@MockBean
	BookingServiceImpl bookingServiceImpl;

	@Test
	public void testAllFavouriteItem() throws Exception {
		mockMvc.perform(get("/booking/1")).andExpect(status().isOk());
	}

	@Test
	public void testAddBookingService() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/booking/1/4")).andExpect(status().isOk());
	}

	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			final String jsonContent = mapper.writeValueAsString(obj);
			return jsonContent;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	@Test
	public void testGetBookingById() throws Exception {
		mockMvc.perform(get("/booking/1")).andExpect(status().isOk());	
	}
	
	@Test
	public void testBookingByIdException() throws Exception {
		mockMvc.perform(get("/booking/1")).andExpect(status().isOk());	
	}
	
	@Test
	public void testTotalBookedService() throws Exception {
		mockMvc.perform(get("/booking/1")).andExpect(status().isOk());	
	}
	
	@Test
	public void testGetBookingById1() throws Exception {
		mockMvc.perform(get("/booking/service/1")).andExpect(status().isOk());	
	}
	@Test
	void testDeleteBookingServiceById200OkTest() throws Exception {
		mockMvc.perform(delete("/booking/1/3")).andExpect(status().isOk());
	}
	
	@Test
	void testShowApproveBooking200OkTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.put("/booking/serviceApprove/6")
						.content(asJsonString(new Booking(1,new User(),new Paw(6,"No","Yes","260/hr","Parasites Check",new java.sql.Date(2022-11-29),"https://upload.wikimedia.org/wikipedia/en/1/14/ParasitesCheck.jpg","Medium dogs"),new java.sql.Date(0001-01-01),"Approved","N/A","N/A","xxxxxxxxxx")))
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)

		).andExpect(status().isOk());
	}
}
