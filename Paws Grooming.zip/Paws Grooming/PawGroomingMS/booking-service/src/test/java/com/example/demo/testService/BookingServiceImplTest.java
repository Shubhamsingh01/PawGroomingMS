package com.example.demo.testService;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;


import java.util.List;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.example.demo.model.Booking;
import com.example.demo.repository.BookingRepository;
import com.example.demo.service.BookingService;


@SpringBootTest
class BookingServiceImplTest {

	@Autowired
    private BookingService bookingService;
	@Autowired
	private BookingRepository bookingRepository;

	@Test
	void testGetAllBookingService() {
		List<Booking> bookList = bookingService.getAllBookingService(1);
		assertEquals(true, bookList.size() != 0);
	}

	@Test
	void testTotalBookingService() {
		List<Booking> book = bookingService.getAllBookingService(1);  
	    assertEquals(true,book.size() != 0 );
	}
	

	@Test
	void testApproveBooking() {
		Booking book = bookingRepository.findId(1);
		book.setStatus("Approved");
		bookingRepository.save(book);
		Booking bookedService = bookingRepository.findId(1);
	    assertThat(bookedService.getStatus()).isEqualTo("Approved");
	}


	@Test
	@Rollback(false)
	public void testDeleteBookingService() {
	    bookingRepository.deleteById(2,4);
	     
	    Booking removedBooking = bookingRepository.findById(2,4); 
	    assertThat(removedBooking).isNull();       
	     
	}
	
}

