create database pawgroomingmicro;
use pawgroomingmicro;
drop database pawgroomingmicro;
show tables;

desc user;
desc booking;

select * from booking;
select * from paw;
select * from User;

INSERT INTO paw VALUES (01,'Yes','Yes','340/hr','2020-04-20','Detangling Hair','https://upload.wikimedia.org/wikipedia/en/f/f8/Detanglig_hair.jpg','Medium dogs');
INSERT INTO paw VALUES (02,'Yes','No','356/hr','2019-11-29','Bathing','https://upload.wikimedia.org/wikipedia/en/2/21/Bathing.jpg','Medium dogs');
INSERT INTO paw VALUES (03,'No','Yes','250/hr','2020-05-7','Nail Clipping','https://upload.wikimedia.org/wikipedia/en/4/46/Nail_clipping.jpg','Small dogs');
INSERT INTO paw VALUES (04,'Yes','Yes','280/hr','2020-05-27','Brushing Teeth','https://upload.wikimedia.org/wikipedia/en/f/f4/Brushing_teeth.jpg','Big dogs');
INSERT INTO paw VALUES (05,'No','No','200/hr','2022-11-29','Deshedding','https://upload.wikimedia.org/wikipedia/en/1/14/Deshedding.jpg','Small dogs');


INSERT INTO booking VALUES (01,01,01);
INSERT INTO booking VALUES (02,01,03);

insert into user values(1,1,"qwerty","ROLE_ADMIN","cogni",1,"cogni");
insert into user values(2,1,"qwerty","ROLE_USER","user",2,"cogni");